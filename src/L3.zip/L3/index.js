import React, { Component } from 'react';
import Level from './Level';
import './style.css';

export default class index extends Component {
    render() {
        return(
            <Level size='10'/>
        );
    }
}